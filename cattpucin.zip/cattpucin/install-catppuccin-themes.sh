#!/bin/bash
# KISS: install Catppuccin themes from cattpucin.zip into /usr/share/themes.
set -eu

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ARCHIVE="$SCRIPT_DIR/cattpucin.zip"
DEST="/usr/share/themes"

if [[ $EUID -ne 0 ]]; then
    exec sudo bash "$0" "$@"
fi

if ! command -v unzip >/dev/null 2>&1; then
    echo "ERROR: unzip is required."
    exit 1
fi

if [[ ! -f "$ARCHIVE" ]]; then
    echo "ERROR: cattpucin.zip must be in the same directory as this script."
    exit 1
fi

WORK="$(mktemp -d)"
trap 'rm -rf -- "$WORK"' EXIT

unzip -q "$ARCHIVE" 'cattpucin/Catppuccin-Dark*' -d "$WORK"

shopt -s nullglob
THEMES=("$WORK"/cattpucin/Catppuccin-Dark*)
if [[ ${#THEMES[@]} -eq 0 ]]; then
    echo "ERROR: no Catppuccin theme folders found in the archive."
    exit 1
fi

install -d "$DEST"
for theme in "${THEMES[@]}"; do
    cp -a -- "$theme" "$DEST/"
    echo "Installed: $(basename "$theme")"
done

echo "Catppuccin themes installed in $DEST."

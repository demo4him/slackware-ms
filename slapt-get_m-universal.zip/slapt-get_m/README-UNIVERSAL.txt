SLACKDEPINFO KISS — SLAPT-GET/LIBSLAPT SOURCE PACKAGE

The installer and source archive are kept together inside this folder. Extract the ZIP anywhere, including ~/Downloads. The script locates its files relative to itself; it does not require a specific username or working directory.

Requirements: Slackware-compatible system, root privileges for installation, Meson, Ninja, compiler/toolchain, makepkg for TXZ creation, and required development libraries.

Run as root from this folder:
  ./script-install-slapt-get-kiss.sh

Menu options build/install directly, create a .txz package, build and install the package, or uninstall the KISS package.

#!/bin/bash
#
# script-install-slapt-get-kiss.sh
# SlackDepInfo KISS - slapt-get/libslapt resolver patch
#
# Options:
#   1 - Build and install directly with Meson (no .txz)
#   2 - Build a Slackware .txz package
#   3 - Build .txz and install it
#   4 - Uninstall the KISS package / restore previous package
#

set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BUILD_DIR="$SCRIPT_DIR/build"
SRC_ARCHIVE="$SCRIPT_DIR/slapt-get-0.11.11-kiss-patched-buildfix.tar.gz"
SRC_DIR="$SCRIPT_DIR/slapt-get-0.11.11-kiss"
PKGROOT="$SCRIPT_DIR/package"
ARCH="$(uname -m)"
case "$ARCH" in
    x86_64) PKGARCH="x86_64" ;;
    i?86)   PKGARCH="i586" ;;
    aarch64) PKGARCH="aarch64" ;;
    *)      PKGARCH="$ARCH" ;;
esac
PKGNAME="slapt-get-0.11.11-${PKGARCH}-2_KISS"
SLACKBUILD="$SCRIPT_DIR/slapt-get.SlackBuild"

die() {
    echo
    echo "ERROR: $*"
    exit 1
}

require_root() {
    [ "$(id -u)" -eq 0 ] || die "Run this script as root."
}

check_tools() {
    command -v meson >/dev/null 2>&1 || die "Meson is not installed."
    command -v ninja >/dev/null 2>&1 || die "Ninja is not installed."
}

extract_source() {
    [ -f "$SRC_ARCHIVE" ] || die "Source archive not found:
  $SRC_ARCHIVE"

    rm -rf "$SRC_DIR"
    tar -xzf "$SRC_ARCHIVE" -C "$SCRIPT_DIR"

    [ -d "$SRC_DIR" ] || die "Source directory was not created."
}

configure_build() {
    cd "$SRC_DIR"

    if [ -d "$BUILD_DIR" ]; then
        meson setup "$BUILD_DIR" \
            --prefix=/usr \
            --sysconfdir=/etc \
            --mandir=/usr/man \
            --buildtype=release \
            --reconfigure
    else
        meson setup "$BUILD_DIR" \
            --prefix=/usr \
            --sysconfdir=/etc \
            --mandir=/usr/man \
            --buildtype=release
    fi
}

direct_install() {
    require_root
    check_tools

    echo
    echo "=============================================="
    echo " Direct Meson installation"
    echo "=============================================="
    echo
    echo "No .txz package will be created."
    echo

    extract_source
    configure_build

    echo
    echo "Building slapt-get + libslapt..."
    meson compile -C "$BUILD_DIR"

    echo
    echo "Installing..."
    meson install -C "$BUILD_DIR"

    /sbin/ldconfig

    echo
    echo "=============================================="
    echo " KISS slapt-get/libslapt installed directly."
    echo "=============================================="
    echo
    echo "Library: /usr/lib64/libslapt.so.0.11.11"
    echo "Binary:  /usr/sbin/slapt-get"
}

write_slack_desc() {
    mkdir -p "$PKGROOT/install"

    cat > "$PKGROOT/install/slack-desc" <<'EOF'
slapt-get: slapt-get package manager
slapt-get:
slapt-get: Slackware package manager with the SlackDepInfo KISS
slapt-get: dependency resolver behavior.
slapt-get:
slapt-get: Installed dependencies satisfy requirements even when they
slapt-get: are listed in EXCLUDE. EXCLUDE remains active for dependencies
slapt-get: that still need installation.
EOF

    cat > "$PKGROOT/install/doinst.sh" <<'EOF'
#!/bin/sh
/sbin/ldconfig
EOF
    chmod 755 "$PKGROOT/install/doinst.sh"
}

build_txz() {
    require_root
    check_tools
    command -v makepkg >/dev/null 2>&1 || die "/sbin/makepkg was not found."

    echo
    echo "=============================================="
    echo " Slackware .txz package"
    echo "=============================================="
    echo

    extract_source
    rm -rf "$BUILD_DIR" "$PKGROOT"
    configure_build

    echo
    echo "Building slapt-get + libslapt..."
    meson compile -C "$BUILD_DIR"

    echo
    echo "Creating package tree..."
    mkdir -p "$PKGROOT"

    meson install -C "$BUILD_DIR" --destdir "$PKGROOT"

    write_slack_desc

    # Never package the build-time Meson manifest.
    rm -rf "$PKGROOT/var/lib"

    PKG="$SCRIPT_DIR/$PKGNAME.txz"
    rm -f "$PKG"

    echo
    echo "Creating TXZ..."
    makepkg -l y -c n "$PKGROOT/$PKGNAME.txz"
    mv "$PKGROOT/$PKGNAME.txz" "$PKG"

    echo
    echo "=============================================="
    echo " TXZ package created"
    echo "=============================================="
    echo
    echo "  $PKG"
    echo
}

build_and_install_txz() {
    build_txz
    PKG="$SCRIPT_DIR/$PKGNAME.txz"

    echo "Installing:"
    echo "  $PKG"
    /sbin/upgradepkg --install-new "$PKG"
    /sbin/ldconfig

    echo
    echo "slapt-get + libslapt installed from the .txz package."
}

uninstall_kiss() {
    require_root

    echo
    echo "=============================================="
    echo " Uninstall KISS slapt-get/libslapt"
    echo "=============================================="
    echo
    echo "This removes only the KISS package:"
    echo "  $PKGNAME"
    echo
    echo "The package database will be used."
    echo
    printf "Are you sure? [y/N]: "
    read -r ANSWER

    case "$ANSWER" in
        y|Y|yes|YES) ;;
        *)
            echo "Cancelled."
            return 0
            ;;
    esac

    PKG_FILE="$(find /var/log/packages -maxdepth 1 -type f \
        -name "$PKGNAME" -printf '%f\n' 2>/dev/null | head -n1 || true)"

    if [ -n "$PKG_FILE" ]; then
        removepkg "$PKG_FILE"
        /sbin/ldconfig
        echo
        echo "KISS package removed."
        return 0
    fi

    # Direct Meson installs are not registered in /var/log/packages.
    # Use Meson's installed-file manifest to remove only files installed
    # by this source build.
    MANIFEST="$BUILD_DIR/meson-info/intro-installed.json"
    if [ -f "$MANIFEST" ]; then
        echo
        echo "No KISS .txz package is registered."
        echo "A direct source installation may be present."
        printf "Uninstall files recorded by this build? [y/N]: "
        read -r ANSWER
        case "$ANSWER" in
            y|Y|yes|YES) ;;
            *)
                echo "Cancelled."
                return 0
                ;;
        esac

        python3 - "$MANIFEST" <<'PYTHON'
import json
import os
import sys

manifest = sys.argv[1]
try:
    with open(manifest, encoding="utf-8") as f:
        installed = json.load(f)
except (OSError, ValueError) as exc:
    print(f"ERROR: Cannot read Meson install manifest: {exc}", file=sys.stderr)
    sys.exit(1)

# Meson commonly writes intro-installed.json as a mapping:
#   {"/build/source/file": "/usr/destination/file", ...}
# The VALUES are the installed destination paths. Never remove mapping keys,
# because those are source/build files and not installed system files.
paths = set()
def collect(obj):
    if isinstance(obj, dict):
        for key in ("destination", "install_filename", "installed_path"):
            value = obj.get(key)
            if isinstance(value, str) and os.path.isabs(value):
                paths.add(value)
        for key, value in obj.items():
            if isinstance(key, str) and key in ("path", "target") and isinstance(value, str) and os.path.isabs(value):
                paths.add(value)
            # Meson's mapping format: source path -> installed destination path.
            if isinstance(key, str) and os.path.isabs(key) and isinstance(value, str) and os.path.isabs(value):
                paths.add(value)
            if isinstance(value, (dict, list)):
                collect(value)
    elif isinstance(obj, list):
        for item in obj:
            collect(item)

collect(installed)
if not paths:
    print("No installed destination paths were found in the Meson manifest.", file=sys.stderr)
    sys.exit(1)

removed = 0
for path in sorted(paths, key=len, reverse=True):
    # Only remove paths from the manifest; never recursively delete directories.
    try:
        if os.path.islink(path) or os.path.isfile(path):
            os.unlink(path)
            print(f"Removed: {path}")
            removed += 1
        elif os.path.isdir(path):
            try:
                os.rmdir(path)  # Remove only empty directories.
                print(f"Removed empty directory: {path}")
            except OSError:
                pass
    except OSError as exc:
        print(f"WARNING: Could not remove {path}: {exc}", file=sys.stderr)

print(f"Source uninstall finished. Files removed: {removed}")
PYTHON
        STATUS=$?
        [ "$STATUS" -eq 0 ] || return "$STATUS"
        /sbin/ldconfig
        return 0
    fi

    echo
    echo "No KISS package is registered, and no Meson install manifest was found."
    echo "For source uninstall, run this script from the same extracted folder"
    echo "used for the direct installation, so its build/ directory is available."
}

[ -f "$SCRIPT_DIR/meson.build" ] || true

while :; do
    clear
    echo "=================================================="
    echo " SlackDepInfo KISS - slapt-get/libslapt"
    echo "=================================================="
    echo
    echo "  1) Install directly with Meson"
    echo "     (no .txz package)"
    echo
    echo "  2) Generate Slackware .txz package"
    echo "     (do not install)"
    echo
    echo "  3) Generate .txz and install it"
    echo
    echo "  4) Uninstall KISS package"
    echo
    echo "  0) Exit"
    echo
    printf "Choose an option [0-4]: "
    read -r CHOICE

    case "$CHOICE" in
        1)
            direct_install
            printf "\nPress Enter to return to the menu..."
            read -r _
            ;;
        2)
            build_txz
            printf "\nPress Enter to return to the menu..."
            read -r _
            ;;
        3)
            build_and_install_txz
            printf "\nPress Enter to return to the menu..."
            read -r _
            ;;
        4)
            uninstall_kiss
            printf "\nPress Enter to return to the menu..."
            read -r _
            ;;
        0)
            exit 0
            ;;
        *)
            echo
            echo "Invalid option."
            sleep 1
            ;;
    esac
done

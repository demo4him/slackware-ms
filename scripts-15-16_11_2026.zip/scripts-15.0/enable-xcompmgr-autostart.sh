#!/bin/sh
# Enable xcompmgr and configure the Whisker Menu appearance for the current XFCE user.

set -eu

# Do not change XFCE settings if xcompmgr is unavailable.
if ! command -v xcompmgr >/dev/null 2>&1; then
    printf 'Error: xcompmgr is not installed or not in PATH.\n' >&2
    exit 1
fi

if ! command -v xfconf-query >/dev/null 2>&1; then
    printf 'Error: xfconf-query was not found; cannot disable XFCE compositing.\n' >&2
    exit 1
fi

# Disable XFCE compositing to avoid a conflict with xcompmgr.
if ! xfconf-query --channel=xfwm4 --property=/general/use_compositing --set=false 2>/dev/null; then
    xfconf-query --channel=xfwm4 --property=/general/use_compositing \
        --create --type=bool --set=false
fi

# Configure xcompmgr autostart with the shadow settings tested in XFCE.
AUTOSTART_DIR="${HOME}/.config/autostart"
DESKTOP_FILE="${AUTOSTART_DIR}/xcompmgr.desktop"

mkdir -p "$AUTOSTART_DIR"

cat > "$DESKTOP_FILE" <<'EOF'
[Desktop Entry]
Type=Application
Name=Xcompmgr
Comment=Subtle desktop window shadows
Exec=xcompmgr -c -o 0.50 -r 12 -l -8 -t -8
Terminal=false
EOF

chmod 644 "$DESKTOP_FILE"

# Add/update only this script's managed Whisker CSS block.
# Any other rules already present in gtk.css are preserved.
GTK_DIR="${HOME}/.config/gtk-3.0"
GTK_CSS="${GTK_DIR}/gtk.css"
CSS_BEGIN='/* BEGIN xcompmgr-autostart: Whisker Menu */'
CSS_END='/* END xcompmgr-autostart: Whisker Menu */'

mkdir -p "$GTK_DIR"

if [ -f "$GTK_CSS" ]; then
    TMP_CSS=$(mktemp "${GTK_CSS}.XXXXXX")
    trap 'rm -f "$TMP_CSS"' EXIT HUP INT TERM

    awk -v begin="$CSS_BEGIN" -v end="$CSS_END" '
        $0 == begin { skip = 1; next }
        $0 == end   { skip = 0; next }
        !skip       { print }
    ' "$GTK_CSS" > "$TMP_CSS"

    cat >> "$TMP_CSS" <<'EOF'

/* BEGIN xcompmgr-autostart: Whisker Menu */
window#whiskermenu-window {
    background-color: rgba(30, 30, 46, 0.90);
    border: none;
    border-radius: 12px;
    background-clip: padding-box;
}

window#whiskermenu-window > frame,
window#whiskermenu-window > frame > border {
    background-color: transparent;
    border: none;
    border-radius: 12px;
    box-shadow: none;
    background-clip: padding-box;
}
/* END xcompmgr-autostart: Whisker Menu */
EOF

    chmod 644 "$TMP_CSS"
    mv "$TMP_CSS" "$GTK_CSS"
    trap - EXIT HUP INT TERM
else
    cat > "$GTK_CSS" <<'EOF'
/* BEGIN xcompmgr-autostart: Whisker Menu */
window#whiskermenu-window {
    background-color: rgba(30, 30, 46, 0.90);
    border: none;
    border-radius: 12px;
    background-clip: padding-box;
}

window#whiskermenu-window > frame,
window#whiskermenu-window > frame > border {
    background-color: transparent;
    border: none;
    border-radius: 12px;
    box-shadow: none;
    background-clip: padding-box;
}
/* END xcompmgr-autostart: Whisker Menu */
EOF
    chmod 644 "$GTK_CSS"
fi

printf 'Xcompmgr autostart enabled: %s\n' "$DESKTOP_FILE"
printf 'Whisker GTK3 styling installed: %s\n' "$GTK_CSS"
printf 'Restart the XFCE panel with: xfce4-panel -r\n'
printf 'Log out and back in for xcompmgr autostart to take effect.\n'

cat > /root/grub-diag.sh <<'EOF'
#!/bin/sh

OUT=/root/grub-diagnostic.txt

{
echo "===== DATE ====="
date
echo

echo "===== KERNEL ====="
uname -r
echo

echo "===== GRUB VERSION ====="
grub-install --version 2>&1
echo

echo "===== ALL_VIDEO ====="
ls -l /usr/lib/grub/x86_64-efi/all_video.mod 2>&1
echo

echo "===== FIND ALL_VIDEO ====="
find /usr/lib/grub /boot/grub -name 'all_video.mod' -ls 2>/dev/null
echo

echo "===== GRUB EFI DIRECTORY ====="
ls -ld /usr/lib/grub/x86_64-efi 2>&1
echo

echo "===== EFI FILES ====="
find /boot/efi/EFI -maxdepth 3 -type f -print 2>/dev/null
echo

echo "===== EFI BOOT ENTRIES ====="
efibootmgr -v 2>&1
echo

echo "===== GRUB DEFAULT/GFX ====="
grep -E '^(GRUB_DEFAULT|GRUB_TERMINAL|GRUB_GFX|GRUB_TIMEOUT)' /etc/default/grub 2>&1
echo

echo "===== CUSTOM GRUB SCRIPT ====="
cat /etc/grub.d/01_slackware-generic 2>&1
echo

echo "===== GRUB CONFIG VIDEO ====="
grep -n -E 'all_video|load_video|gfxterm|video' /boot/grub/grub.cfg 2>&1
echo

echo "===== GRUB CONFIG GENERIC ====="
grep -n -A5 "Slackware Generic 6.12.110" /boot/grub/grub.cfg 2>&1
echo

echo "===== GRUB MODULES ====="
ls /usr/lib/grub/x86_64-efi 2>&1
echo

echo "===== BOOT FILES ====="
ls -lh /boot/vmlinuz-generic-6.12.110 \
       /boot/initrd-generic-6.12.110.gz \
       /boot/amd-ucode.img 2>&1
echo

echo "===== END ====="
} > "$OUT"

echo
echo "Diagnostic saved to:"
echo "$OUT"
echo
echo "File size:"
ls -lh "$OUT"
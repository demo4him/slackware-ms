#!/bin/bash
# Remove leftover Adwaita-named theme artifacts. Default is a safe dry run.
set -u

APPLY=0
case "${1:-}" in
  "") ;;
  --apply) APPLY=1 ;;
  --help|-h)
    cat <<'HELP'
Usage:
  ./remove-adwaita-artifacts.sh          # preview only
  ./remove-adwaita-artifacts.sh --apply  # confirm, then delete

Scans common GTK/XFCE theme locations, /tmp, Downloads, and Desktop.
Only paths with "adwaita" in their name are selected.
HELP
    exit 0 ;;
  *) echo "Unknown option: $1 (use --help)" >&2; exit 2 ;;
esac

ROOTS=(
  "$HOME/.themes"
  "$HOME/.local/share/themes"
  "$HOME/.local/share/xfce4"
  "/usr/share/themes"
  "/usr/local/share/themes"
  "/tmp"
)

# If invoked as root through `su -`, also check the usual user's theme/download dirs.
if [[ "${HOME:-}" == "/root" && -d "/home/marius" ]]; then
  ROOTS+=(
    "/home/marius/.themes"
    "/home/marius/.local/share/themes"
   )
fi

matches_file="$(mktemp)" || exit 1
trap 'rm -f "$matches_file"' EXIT

for root in "${ROOTS[@]}"; do
  [[ -d "$root" ]] || continue
  find "$root" -xdev -iname '*adwaita*' -print0 2>/dev/null >> "$matches_file"
done

if [[ ! -s "$matches_file" ]]; then
  echo "No Adwaita-named artifacts found in the configured locations."
  exit 0
fi

echo "Matching paths:"
while IFS= read -r -d '' path; do printf '  %s\n' "$path"; done < "$matches_file"

if (( ! APPLY )); then
  echo
  echo "DRY RUN: nothing was deleted."
  echo "Review the list, then run with --apply to remove the matches."
  exit 0
fi

echo
read -r -p "Delete all listed paths? Type YES to continue: " confirm
[[ "$confirm" == "YES" ]] || { echo "Cancelled; nothing was deleted."; exit 0; }

failed=0
while IFS= read -r -d '' path; do
  [[ -n "$path" && "$path" != "/" ]] || continue
  if rm -rf -- "$path"; then
    printf 'Removed: %s\n' "$path"
  else
    printf 'FAILED: %s\n' "$path" >&2
    failed=1
  fi
done < "$matches_file"

if (( failed )); then
  echo "Cleanup finished with errors; review FAILED entries." >&2
  exit 1
fi
echo "Cleanup completed."
echo "This removes matching files/directories, not Slackware package database entries."

#!/bin/bash
sudo chown -hR marius:root /PERSONAL
sudo chown -hR marius:root /home/marius/*
sudo chown -hR marius:root /PERSONAL/marius/*
sudo chmod o+rw /dev/bus/usb*
sudo chmod o+rw /PERSONAL/*
sudo chmod o+rw /PERSONAL/marius/*
sudo chmod o+rw /dev/video*
echo "DONE!"

sleep 3
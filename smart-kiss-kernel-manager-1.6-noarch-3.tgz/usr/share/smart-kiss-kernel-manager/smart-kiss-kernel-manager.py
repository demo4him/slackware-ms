#!/usr/bin/env python3
import os
import re
import subprocess
import shutil
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf, Gdk, Pango, GLib


ANSI_ESCAPE_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1B\\))")
CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]")

def clean_workflow_output(text):
    """Remove terminal control sequences before showing backend output in GTK."""
    text = ANSI_ESCAPE_RE.sub("", text)
    return CONTROL_CHARS_RE.sub("", text)


def workflow_resource_path(name):
    """Find a workflow resource in the extracted source tree or installed layout."""
    source_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
    source_candidate = os.path.join(source_root, "libexec", name)
    if os.path.isfile(source_candidate):
        return source_candidate
    return os.path.join("/usr/libexec", name)

APP_NAME = "Smart-KISS Kernel Manager"
APP_VERSION = "1.6"

# Slackware 15.0 policy: stable patch releases from the 6.12 series only.
# Patch releases are discovered dynamically; no specific patch number is pinned.
KERNEL_INDEX_URL = "https://www.kernel.org/releases.json"

def is_allowed_kernel_version(version):
    """Accept only stable 6.12.N versions; reject RCs and malformed input."""
    import re
    return bool(re.fullmatch(r"6\.12\.(0|[1-9][0-9]*)", version or ""))

def discover_kernel_versions(timeout=12):
    """Discover available stable 6.12.x source tarballs from kernel.org archive."""
    import re
    import urllib.request
    archive_url = "https://cdn.kernel.org/pub/linux/kernel/v6.x/"
    try:
        request = urllib.request.Request(
            archive_url,
            headers={"User-Agent": f"{APP_NAME}/{APP_VERSION}"}
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            listing = response.read().decode("utf-8", errors="replace")
        versions = set(re.findall(r'href="linux-(6\.12\.(?:0|[1-9][0-9]*))\.tar\.xz"', listing))
        return sorted(versions, key=lambda v: tuple(map(int, v.split("."))), reverse=True)
    except Exception:
        return []

PROFILES = [
    ("generic", "1. Generic", "Standard Slackware configuration", "applications-system-symbolic"),
    ("voluntary", "2. Desktop/Multimedia", "Desktop profile with voluntary preemption and multimedia", "preferences-system-symbolic"),
    ("games", "3. Games", "Gaming preset: voluntary preemption and 1000 Hz timer, if supported", "input-gaming-symbolic"),
    ("huge", "4. Huge", "Build using an installed Slackware huge-kernel configuration", "drive-harddisk-symbolic"),
]

class KernelManager(Gtk.Window):
    def __init__(self):
        super().__init__(title=APP_NAME)
        # Track one privileged workflow at a time without opening xterm.
        self.workflow_process = None
        self.workflow_title = None
        self.progress_window = None
        self.progress_bar = None
        self.progress_label = None
        self.progress_log_buffer = None
        self.progress_log_view = None
        self.workflow_log_offset = 0
        self.workflow_last_stage = ""
        self.set_default_size(620, 540)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_border_width(6)
        self.selected_profile = "generic"
        self.add_css()

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7)
        self.add(outer)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
        # Prefer the mascot shipped alongside the application.  Keep the
        # system pixmaps path as a compatibility fallback; a missing image
        # must never prevent the manager window from starting.
        app_dir = os.path.dirname(os.path.abspath(__file__))
        mascot_candidates = (
            os.path.join(app_dir, "tux-cyber-kiss-128.png"),
            "/usr/share/pixmaps/smart-kiss-kernel-manager.png",
        )
        mascot = None
        for mascot_path in mascot_candidates:
            if os.path.isfile(mascot_path):
                try:
                    mascot = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        mascot_path, 120, 120, True
                    )
                    break
                except GLib.Error:
                    pass
        icon = Gtk.Image.new_from_pixbuf(mascot) if mascot else Gtk.Image.new()
        header.pack_start(icon, False, False, 0)
        titles = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        title = Gtk.Label()
        title.set_markup('<span size="x-large" weight="bold">Smart-KISS Kernel Manager</span>')
        title.set_xalign(0)
        subtitle = Gtk.Label(label="Slackware 15.0 · x86_64 · Linux 6.12.x")
        subtitle.set_xalign(0)
        subtitle.get_style_context().add_class("dim-label")
        titles.pack_start(title, False, False, 0)
        titles.pack_start(subtitle, False, False, 0)
        header.pack_start(titles, True, True, 0)
        outer.pack_start(header, False, False, 0)

        outer.pack_start(self.section_label("Select kernel profile"), False, False, 0)
        grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        grid.set_column_homogeneous(True)
        grid.set_row_homogeneous(True)
        for idx, (key, label, desc, icon_name) in enumerate(PROFILES):
            button = Gtk.Button()
            button.set_relief(Gtk.ReliefStyle.NONE)
            button.set_size_request(-1, 82)
            button.set_hexpand(True)
            button.set_vexpand(False)
            button.get_style_context().add_class("profile-card")
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
            image = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
            image.set_pixel_size(36)
            text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            name = Gtk.Label()
            name.set_markup(f'<span weight="bold">{label}</span>')
            name.set_xalign(0)
            detail = Gtk.Label(label=desc)
            detail.set_xalign(0)
            detail.set_line_wrap(True)
            detail.set_max_width_chars(35)
            detail.get_style_context().add_class("dim-label")
            text_box.pack_start(name, False, False, 0)
            text_box.pack_start(detail, False, False, 0)
            box.pack_start(image, False, False, 0)
            box.pack_start(text_box, True, True, 0)
            button.add(box)
            button.connect("clicked", self.on_profile, key)
            grid.attach(button, idx % 2, idx // 2, 1, 1)
        outer.pack_start(grid, False, False, 0)

        self.selected_label = Gtk.Label()
        self.selected_label.set_xalign(0)
        self.selected_label.set_markup("Selected profile: <b>Generic</b>")
        outer.pack_start(self.selected_label, False, False, 0)

        outer.pack_start(self.section_label("Kernel workflow"), False, False, 0)
        actions = Gtk.Grid(column_spacing=10, row_spacing=10)
        actions.set_column_homogeneous(True)
        actions.set_row_homogeneous(True)
        actions.attach(self.action_button("drive-harddisk-symbolic", "Prebuilt Kernel", "Install all matching packages for the latest 5.15.x kernel", self.prebuilt_info), 0, 0, 1, 1)
        actions.attach(self.action_button("applications-development-symbolic", "Build from Source", "Choose any available stable 6.12.x release", self.build_from_source), 1, 0, 1, 1)
        actions.attach(self.action_button("dialog-information-symbolic", "System Information", "Show current kernel and CPU information", self.system_info), 0, 1, 1, 1)
        actions.attach(self.action_button("document-revert-symbolic", "Backup & Recovery", "Review the kernel recovery policy", self.recovery_info), 1, 1, 1, 1)
        outer.pack_start(actions, False, False, 0)

        note = Gtk.Label()
        note.set_line_wrap(True)
        note.set_xalign(0)
        note.set_markup('<span size="small">Kernel tools: source build and official Current package workflow. Keep the previous working kernel until the new one is tested.</span>')
        note.get_style_context().add_class("dim-label")
        outer.pack_start(note, False, False, 0)

        close_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        about = Gtk.Button(label="About")
        about.set_relief(Gtk.ReliefStyle.NONE)
        about.get_style_context().add_class("dim-label")
        about.connect("clicked", self.about_info)
        close_row.pack_start(about, False, False, 0)
        spacer = Gtk.Box()
        close_row.pack_start(spacer, True, True, 0)
        close = Gtk.Button(label="Close")
        close.connect("clicked", lambda *_: Gtk.main_quit())
        close_row.pack_end(close, False, False, 0)
        outer.pack_start(close_row, False, False, 0)

    def add_css(self):
        css = b'''
        window { background: @theme_bg_color; }
        .profile-card { background: alpha(@theme_fg_color, 0.07); border: 1px solid alpha(@theme_fg_color, 0.08); border-radius: 12px; padding: 10px; }
        .profile-card:hover { background: alpha(@theme_selected_bg_color, 0.20); }
        .section-title { font-weight: bold; font-size: 1.05em; margin-top: 4px; }
        .action-card { background: alpha(@theme_fg_color, 0.07); border-radius: 10px; padding: 10px; }
        .dim-label { opacity: 0.78; }
        '''
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def section_label(self, text):
        label = Gtk.Label(label=text)
        label.set_xalign(0)
        label.get_style_context().add_class("section-title")
        return label

    def action_button(self, icon_name, title, desc, callback):
        button = Gtk.Button()
        button.set_relief(Gtk.ReliefStyle.NONE)
        button.set_size_request(-1, 82)
        button.set_hexpand(True)
        button.set_vexpand(False)
        button.get_style_context().add_class("profile-card")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
        image = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
        image.set_pixel_size(32)
        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        name = Gtk.Label()
        name.set_markup(f'<span weight="bold">{GLib.markup_escape_text(title)}</span>')
        name.set_xalign(0)
        detail = Gtk.Label(label=desc)
        detail.set_xalign(0)
        detail.set_line_wrap(True)
        detail.set_max_width_chars(32)
        detail.get_style_context().add_class("dim-label")
        text_box.pack_start(name, False, False, 0)
        text_box.pack_start(detail, False, False, 0)
        box.pack_start(image, False, False, 0)
        box.pack_start(text_box, True, True, 0)
        button.add(box)
        button.connect("clicked", callback)
        return button

    def about_info(self, *_):
        self.message(
            "About Smart-KISS Kernel Manager",
            "Smart-KISS Kernel Manager builds Linux kernels for Slackware 15.0. "
            "Choose a kernel version and build profile, detect the root partition "
            "automatically or select it manually, and generate an initrd. "
            "The manager does not reboot your computer automatically.\n\n"
            "Important: Slackware's installer offers ext4 as a filesystem option, "
            "but not every installation uses ext4. This manager's current initrd "
            "workflow supports ext4 root partitions only. Other filesystems, "
            "encrypted roots, and some LVM setups may need additional configuration."
        )

    def on_profile(self, _button, key):
        labels = dict((p[0], p[1]) for p in PROFILES)
        if key == "generic":
            confirm = Gtk.MessageDialog(
                transient_for=self, flags=0, message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.OK_CANCEL, text="Select Generic profile?"
            )
            confirm.format_secondary_text(
                "Generic uses the same validated voluntary-preemption preset as Desktop/Multimedia.\n\n"
                "Selecting it does not start a build. You will receive another confirmation before compilation begins."
            )
            accepted = confirm.run() == Gtk.ResponseType.OK
            confirm.destroy()
            if not accepted:
                return
        elif key == "games":
            self.message(
                "Games profile",
                "Uses the same validated voluntary-preemption preset as Desktop/Multimedia and Generic, "
                "while retaining the 1000 Hz timer where supported. The build stops if the required settings "
                "are unavailable after Kconfig resolves the configuration."
            )
        elif key == "huge":
            self.message(
                "Huge profile",
                "Uses the newest available installed Slackware config-huge file as the base and skips localmodconfig to preserve broad driver support. If no huge configuration is found, the build stops safely."
            )
        if key == "voluntary":
            confirm = Gtk.MessageDialog(
                transient_for=self, flags=0, message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.OK_CANCEL, text="Select Desktop/Multimedia profile?"
            )
            confirm.format_secondary_text(
                "This profile targets desktop responsiveness, voluntary preemption, and multimedia use.\n\n"
                "Selecting it does not start a build. You will receive another confirmation before compilation begins."
            )
            accepted = confirm.run() == Gtk.ResponseType.OK
            confirm.destroy()
            if not accepted:
                return
        self.selected_profile = key
        self.selected_label.set_markup(f"Selected profile: <b>{labels[key]}</b>")

    def message(self, title, body):
        dialog = Gtk.MessageDialog(transient_for=self, flags=0, message_type=Gtk.MessageType.INFO, buttons=Gtk.ButtonsType.OK, text=title)
        dialog.format_secondary_text(body)
        dialog.run()
        dialog.destroy()


    def check_workflow_runtime(self, backend):
        """Validate the interactive workflow runtime before any privileged process starts."""
        pkexec = shutil.which("pkexec")
        adapter = workflow_resource_path("dialog")
        problems = []
        if not pkexec:
            problems.append(
                "pkexec is missing. The terminal-free workflow requires PolicyKit (pkexec) "
                "and a running graphical authentication agent. No build or installation was started."
            )
        else:
            try:
                agent = subprocess.run(
                    ["/usr/bin/pgrep", "-af", "polkit-gnome-authentication-agent-1"],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                    timeout=3, check=False
                )
                if agent.returncode != 0:
                    problems.append(
                        "The GNOME PolicyKit authentication agent is not running in this session. "
                        "Start it before using the terminal-free workflow. No build or installation was started."
                    )
            except Exception:
                problems.append(
                    "Could not verify the graphical PolicyKit authentication agent. "
                    "No build or installation was started."
                )
        if not os.path.isfile(backend) or not os.access(backend, os.X_OK):
            problems.append(f"Workflow backend is missing or not executable:\n{backend}")
        if not os.path.isfile(adapter) or not os.access(adapter, os.X_OK):
            problems.append(f"GTK3 dialog adapter is missing or not executable:\n{adapter}")
        else:
            try:
                probe = subprocess.run(
                    ["/usr/bin/python3", "-c",
                     'import gi; gi.require_version("Gtk", "3.0"); from gi.repository import Gtk; print("GTK3 OK")'],
                    text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    timeout=8, check=False
                )
                if probe.returncode != 0:
                    detail = (probe.stderr or probe.stdout or "GTK3 import test failed").strip()
                    problems.append("Python GTK3 support is unavailable:\n" + detail)
            except Exception as exc:
                problems.append("Could not verify Python GTK3 support:\n" + str(exc))
        if problems:
            self.message("Workflow preflight failed", "No build or installation was started.\n\n" + "\n\n".join(problems))
            return None
        return pkexec

    def launch_privileged_workflow(self, backend, title, args=None):
        """Launch and monitor the root Bash engine through PolicyKit, without xterm."""
        if self.workflow_process is not None and self.workflow_process.poll() is None:
            self.message(
                "Workflow already running",
                f"{self.workflow_title or 'A privileged workflow'} is still running. "
                "Wait for it to finish before starting another operation."
            )
            return

        pkexec = self.check_workflow_runtime(backend)
        if pkexec is None:
            return
        # pkexec intentionally filters most environment variables. The GTK3
        # dialog adapter runs inside the privileged Bash engine, so explicitly
        # pass only the X11 display and authority file needed to open its windows.
        # Do not use xhost or disable X11 access controls.
        display = os.environ.get("DISPLAY", "")
        xauthority = os.environ.get("XAUTHORITY", "")
        if not display or not xauthority:
            self.message(
                "Graphical environment unavailable",
                "DISPLAY or XAUTHORITY is not set in this X11 session. "
                "No build or installation was started."
            )
            return

        # Make the matching adapter directory the first inherited PATH entry.
        # The Bash engines prepend /usr/libexec themselves, then retain this PATH;
        # this lets an extracted test tree supply its own GTK3 adapter while an
        # installed workflow naturally resolves /usr/libexec/dialog.
        adapter_dir = os.path.dirname(os.path.abspath(workflow_resource_path("dialog")))
        system_path = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        workflow_path = f"{adapter_dir}:{system_path}"
        command = [
            pkexec, "/usr/bin/env",
            f"DISPLAY={display}",
            f"XAUTHORITY={xauthority}",
            f"PATH={workflow_path}",
            backend,
        ]
        if args:
            command.extend(args)
        try:
            self.workflow_log = "/tmp/smart-kiss-kernel-manager-workflow.log"
            log_stream = open(self.workflow_log, "w", encoding="utf-8")
            try:
                self.workflow_process = subprocess.Popen(
                    command,
                    start_new_session=True,
                    stdin=subprocess.DEVNULL,
                    stdout=log_stream,
                    stderr=subprocess.STDOUT,
                )
            finally:
                log_stream.close()
            self.workflow_title = title
            self._show_workflow_progress(title)
            # Keep the progress window alive and follow the root workflow log.
            GLib.timeout_add(350, self._update_workflow_progress)
            GLib.timeout_add(500, self._poll_privileged_workflow)
        except Exception as exc:
            self.workflow_process = None
            self.workflow_title = None
            self._close_workflow_progress()
            self.message("Could not start workflow", str(exc))

    def _show_workflow_progress(self, title):
        """Show one persistent GTK progress window for the complete workflow."""
        win = Gtk.Window(title=title)
        win.set_transient_for(self)
        win.set_modal(False)
        win.set_position(Gtk.WindowPosition.CENTER)
        win.set_default_size(760, 480)
        win.set_border_width(14)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=9)
        win.add(box)
        label = Gtk.Label(label="Preparing workflow…")
        label.set_xalign(0)
        label.set_line_wrap(True)
        bar = Gtk.ProgressBar()
        bar.set_show_text(True)
        bar.set_fraction(0.02)
        bar.set_text("Starting…")
        note = Gtk.Label(label="Live workflow output · compilation percentage is not available, so the bar pulses during make.")
        note.set_xalign(0)
        note.get_style_context().add_class("dim-label")
        log_view = Gtk.TextView()
        log_view.set_editable(False)
        log_view.set_cursor_visible(False)
        log_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        log_view.set_monospace(True)
        log_buffer = log_view.get_buffer()
        log_scroll = Gtk.ScrolledWindow()
        log_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        log_scroll.set_hexpand(True)
        log_scroll.set_vexpand(True)
        log_scroll.add(log_view)
        box.pack_start(label, False, False, 0)
        box.pack_start(bar, False, False, 0)
        box.pack_start(note, False, False, 0)
        box.pack_start(log_scroll, True, True, 0)
        # Prevent accidental dismissal while the privileged workflow is active.
        win.connect("delete-event", lambda *_: True)
        self.progress_window = win
        self.progress_bar = bar
        self.progress_label = label
        self.progress_log_buffer = log_buffer
        self.progress_log_view = log_view
        self.workflow_log_offset = 0
        self.workflow_last_stage = ""
        win.show_all()

    def _update_workflow_progress(self):
        """Map real workflow log milestones to the persistent GTK progress bar."""
        if self.workflow_process is None or self.progress_bar is None:
            return GLib.SOURCE_REMOVE
        try:
            with open(getattr(self, "workflow_log", "/tmp/smart-kiss-kernel-manager-workflow.log"), "r", encoding="utf-8", errors="replace") as stream:
                stream.seek(self.workflow_log_offset)
                chunk = clean_workflow_output(stream.read())
                self.workflow_log_offset = stream.tell()
        except OSError:
            chunk = ""
        if chunk:
            # Show the complete backend output in the same persistent GTK window.
            # Keep original line breaks so errors and make output remain readable.
            if self.progress_log_buffer is not None:
                end_iter = self.progress_log_buffer.get_end_iter()
                self.progress_log_buffer.insert(end_iter, chunk)
                mark = self.progress_log_buffer.create_mark(None, self.progress_log_buffer.get_end_iter(), False)
                self.progress_log_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
            lines = [line.strip() for line in chunk.splitlines() if line.strip()]
            stages = [
                ("Downloading Kernel", 0.08, "Downloading kernel source…"),
                ("Fetching linux-", 0.08, "Downloading kernel source…"),
                ("Extracting kernel sources", 0.18, "Extracting kernel source…"),
                ("Cleaning source tree", 0.23, "Preparing source tree…"),
                ("Copying Slackware base configuration", 0.30, "Preparing kernel configuration…"),
                ("make olddefconfig", 0.36, "Validating kernel configuration…"),
                ("Compiling kernel", 0.40, "Compiling kernel — this may take a long time…"),
                ("Installing modules", 0.82, "Installing kernel modules…"),
                ("PROTECTED BACKUP STAGE", 0.87, "Backing up existing boot files…"),
                ("Copying final build binaries", 0.90, "Installing kernel files in /boot…"),
                ("PROTECTED INITRD STAGE", 0.92, "Generating initrd…"),
                ("Updating boot directory symlinks", 0.95, "Updating kernel links…"),
                ("Kernel backup created", 0.97, "Updating bootloader…"),
                ("Workflow Complete", 1.0, "Workflow completed successfully."),
            ]
            for line in lines:
                for marker, fraction, message in stages:
                    if marker.lower() in line.lower():
                        self.workflow_last_stage = message
                        self.progress_label.set_text(message)
                        self.progress_bar.set_fraction(fraction)
                        self.progress_bar.set_text(f"{int(fraction * 100)}%")
                        break
                if line.startswith("ERROR:"):
                    self.workflow_last_stage = line
                    self.progress_label.set_text(line)
        # Compilation has no reliable native percentage; pulse honestly rather than
        # inventing a precise percentage while make is working.
        if "Compiling kernel" in self.workflow_last_stage and self.workflow_process.poll() is None:
            self.progress_bar.pulse()
            self.progress_bar.set_text("Compiling…")
        return GLib.SOURCE_CONTINUE

    def _close_workflow_progress(self):
        if self.progress_window is not None:
            self.progress_window.destroy()
        self.progress_window = None
        self.progress_bar = None
        self.progress_label = None
        self.progress_log_buffer = None
        self.progress_log_view = None

    def _poll_privileged_workflow(self):
        """Report completion without blocking GTK or changing the Bash engine."""
        process = self.workflow_process
        if process is None:
            return GLib.SOURCE_REMOVE

        return_code = process.poll()
        if return_code is None:
            return GLib.SOURCE_CONTINUE

        # Drain any final output before closing the live log window.
        self._update_workflow_progress()
        title = self.workflow_title or "Privileged workflow"
        self.workflow_process = None
        self.workflow_title = None
        self._close_workflow_progress()
        if return_code == 0:
            self.message(
                "Workflow finished",
                f"{title} finished with exit code 0. Review the workflow's final messages before rebooting."
            )
        else:
            try:
                with open(getattr(self, "workflow_log", "/tmp/smart-kiss-kernel-manager-workflow.log"), encoding="utf-8", errors="replace") as log_file:
                    log_text = log_file.read().strip()
                details = "\n\nLast workflow output:\n" + log_text[-3500:] if log_text else "\n\nThe workflow log is empty."
            except OSError as exc:
                details = f"\n\nCould not read workflow log: {exc}"
            self.message(
                "Workflow did not finish successfully",
                f"{title} ended with exit code {return_code}.{details}"
            )
        return GLib.SOURCE_REMOVE

    def build_from_source(self, *_):
        versions = discover_kernel_versions()
        versions = [v for v in versions if is_allowed_kernel_version(v)]
        if not versions:
            self.message(
                "Kernel releases unavailable",
                "Could not retrieve stable 6.12.x releases from kernel.org. "
                "No fallback version is selected automatically. Check the connection and try again."
            )
            return

        dialog = Gtk.Dialog(
            title="Build Kernel from Source",
            transient_for=self,
            flags=0
        )
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Continue", Gtk.ResponseType.OK)
        dialog.set_default_size(420, 180)
        area = dialog.get_content_area()
        area.set_spacing(10)
        area.set_border_width(12)

        version_label = Gtk.Label(label="Choose a Linux 6.12.x release:")
        version_label.set_xalign(0)
        version_combo = Gtk.ComboBoxText()
        for version in versions:
            version_combo.append_text(version)
        version_combo.set_active(0)

        cores_label = Gtk.Label(label="Parallel build jobs:")
        cores_label.set_xalign(0)
        cores_spin = Gtk.SpinButton.new_with_range(1, max(1, os.cpu_count() or 1), 1)
        cores_spin.set_value(max(1, os.cpu_count() or 1))

        profile_name = {"generic": "Generic", "voluntary": "Desktop/Multimedia", "games": "Games", "huge": "Huge"}[self.selected_profile]
        profile_label = Gtk.Label(label=f"Profile: {profile_name}")
        profile_label.set_xalign(0)

        area.pack_start(version_label, False, False, 0)
        area.pack_start(version_combo, False, False, 0)
        area.pack_start(cores_label, False, False, 0)
        area.pack_start(cores_spin, False, False, 0)
        area.pack_start(profile_label, False, False, 0)
        dialog.show_all()
        response = dialog.run()
        version = version_combo.get_active_text()
        cores = cores_spin.get_value_as_int()
        dialog.destroy()
        if response != Gtk.ResponseType.OK or not version:
            return
        if not is_allowed_kernel_version(version):
            self.message("Rejected kernel version", "Only stable 6.12.N releases are accepted.")
            return

        confirm = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text="Start the kernel build workflow?"
        )
        confirm.format_secondary_text(
            f"Kernel: {version}\nProfile: {profile_name}\nBuild jobs: {cores}\n\n"
            "The workflow requires administrator privileges and may take a long time. "
            "Review every kernel configuration and bootloader prompt. Keep the current working kernel."
        )
        accepted = confirm.run() == Gtk.ResponseType.OK
        confirm.destroy()
        if not accepted:
            return

        backend = workflow_resource_path("smart-kiss-kernel-build")
        # Start the unchanged Bash engine through PolicyKit; no xterm is opened.
        # The GTK3 dialog adapter supplies the workflow's interactive UI.
        self.launch_privileged_workflow(
            backend, "Smart-KISS Kernel Build",
            [version, str(cores), self.selected_profile]
        )

    def prebuilt_info(self, *_):
        dialog = Gtk.MessageDialog(
            transient_for=self, flags=0, message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK_CANCEL, text="Install all matching packages for the latest Slackware64 15.0 5.15.x kernel?"
        )
        dialog.format_secondary_text(
            "This installs every version-matched kernel package available in the official Slackware64 15.0 "
            "kernel directory (for example generic, huge, modules and source). It does not run a system-wide upgrade.\n\n"
            "The current kernel files are preserved. The installer checks the repository checksum list and "
            "requires an ext4 root filesystem for initrd generation. A Current kernel may still be incompatible "
            "with some Slackware 15.0 setups. No reboot is automatic."
        )
        accepted = dialog.run() == Gtk.ResponseType.OK
        dialog.destroy()
        if not accepted:
            return
        backend = workflow_resource_path("smart-kiss-kernel-prebuilt")
        # Use the same terminal-free PolicyKit launch as the source-build workflow.
        self.launch_privileged_workflow(backend, "Smart-KISS Prebuilt Kernel")

    def not_ready(self, *_):
        self.message("Not connected yet", "This action is intentionally disabled in this manager. Dynamic kernel.org discovery and stable 6.12.x validation are defined, but build/install integration still requires profile mapping, package checks, and boot/recovery safety checks.")

    def system_info(self, *_):
        try:
            kernel = subprocess.check_output(["uname", "-r"], text=True).strip()
        except Exception:
            kernel = "Unknown"
        try:
            cpu = subprocess.check_output(["nproc"], text=True).strip() + " logical CPU cores"
        except Exception:
            cpu = "Unknown"
        self.message("System Information", f"Running kernel: {kernel}\nArchitecture: {os.uname().machine}\nCPU: {cpu}\nTarget: Slackware64 15.0 / prebuilt 5.15.x or source 6.12.x")

    def recovery_info(self, *_):
        self.message("Backup & Recovery", "Policy: keep the currently working kernel bootable; back up kernel image, System.map, config and initrd; update bootloader entries only after successful build and verification. This manager DOES modify /boot: it writes versioned kernel, System.map, config and initrd files, updates the standard /boot symlinks after initrd generation succeeds, and may regenerate GRUB configuration. It creates backups before changing boot files. Keep a known-working kernel and its boot entry until the new kernel has been tested.")

if __name__ == "__main__":
    win = KernelManager()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()

#!/bin/bash
# ==============================================================================
# Automated script to uninstall MS Office 2007 on Slackware 15-current
# Created in collaboration: Marius & AI Collaborator (Monolithic Uninstaller Master)
# ==============================================================================
set -e

# Dynamically get the current Slackware username
CURRENT_USER=$(whoami)

# Path variables matching those used by the installation script
WINEPREFIX="/home/${CURRENT_USER}/.winecx-office2007"
LAUNCHERS_DIR="/opt/winecx/launchers"
APPLICATIONS_DIR="/usr/share/applications"
ICONS_DIR="/usr/share/icons/hicolor/256x256/apps"

# Interactive startup dialog
dialog --title "Uninstall MS Office 2007" \
       --yesno "\nHello Friend!\n\nDo you want to COMPLETELY remove Microsoft Office 2007?\nThis will remove the Wine prefix, launchers, and icons." 9 65

if [ $? -eq 0 ]; then
    # 1. Force-close any Wine processes associated with this prefix before removal
    if [ -d "$WINEPREFIX" ]; then
        dialog --title "Stop Processes" --infobox "Stopping active Wine servers for this prefix..." 5 55
        WINEPREFIX="$WINEPREFIX" /opt/winecx/bin/wineserver -k >/dev/null 2>&1 || true
        sleep 1
    fi

    # 2. Remove the isolated prefix
    dialog --title "Cleaning Data" --infobox "Removing Wine prefix: $WINEPREFIX..." 5 60
    rm -rf "$WINEPREFIX"

    # 3. Remove wrappers from /opt (root privileges required)
    dialog --title "Cleaning Executables" --infobox "Removing launcher scripts from /opt/winecx/launchers/..." 5 60
    sudo rm -f "$LAUNCHERS_DIR/word2007.sh"
    sudo rm -f "$LAUNCHERS_DIR/excel2007.sh"
    sudo rm -f "$LAUNCHERS_DIR/powerpoint2007.sh"
    
    # Try to remove the launchers directory if it is completely empty
    sudo rmdir "$LAUNCHERS_DIR" 2>/dev/null || true

    # 4. Remove system desktop launchers (root privileges required)
    dialog --title "Cleaning Menu" --infobox "Removing .desktop files from the system menu..." 5 60
    sudo rm -f "$APPLICATIONS_DIR/word2007.desktop"
    sudo rm -f "$APPLICATIONS_DIR/excel2007.desktop"
    sudo rm -f "$APPLICATIONS_DIR/powerpoint2007.desktop"
    sudo rm -f "$APPLICATIONS_DIR/onenote2007.desktop"

    # 5. Remove installed icons (root privileges required)
    dialog --title "Cleaning Icons" --infobox "Removing high-quality icons from the system icon theme..." 5 60
    sudo rm -f "$ICONS_DIR/word2007.png"
    sudo rm -f "$ICONS_DIR/excel2007.png"
    sudo rm -f "$ICONS_DIR/powerpoint2007.png"
    sudo rm -f "$ICONS_DIR/onenote2007.png"

    # Also remove any OneNote 2007 icon copies in other hicolor application sizes.
    for icon_size_dir in /usr/share/icons/hicolor/*/apps; do
        [ -d "$icon_size_dir" ] || continue
        sudo rm -f "$icon_size_dir/onenote2007.png"
    done

    # Remove a possible user-local copy of the OneNote icon, if present.
    if [ -d "/home/${CURRENT_USER}/.local/share/icons" ]; then
        find "/home/${CURRENT_USER}/.local/share/icons" -type f -name "onenote2007.png" -delete 2>/dev/null || true
    fi

    # 6. Update system databases (MIME, desktop entries, and icons)
    dialog --title "Updating System" --infobox "Refreshing graphical menus and the Slackware icon cache..." 5 60
    sudo gtk-update-icon-cache -f -q /usr/share/icons/hicolor/
    sudo update-desktop-database /usr/share/applications

    # Fereastră finală de succes
    dialog --title "Uninstallation Successful" \
           --msgbox "\nCleanup completed successfully!\n\nAll traces of Office 2007 have been completely removed from Slackware." 9 65
else
    clear
    echo "The uninstallation operation was canceled by the user."
fi

clear

Gslapt Modern - universal source installer

1. Extract the complete ZIP archive to any directory (for example, ~/Downloads).
2. Keep script-install-gslapt.sh beside the gslapt-modern-... source folder.
3. Run from any working directory with: bash /path/to/script-install-gslapt.sh
   Or make it executable and launch it directly.
4. The installer finds the source folder relative to its own location. Do not move
   the installer away from the source folder.

The installer needs root privileges for installation/package operations and the
normal build dependencies for Gslapt on Slackware. The source folder contains
the source files; the installer is intentionally outside it for easy discovery.

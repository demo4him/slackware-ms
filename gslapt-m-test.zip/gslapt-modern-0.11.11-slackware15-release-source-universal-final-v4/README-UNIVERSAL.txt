GSLAPT MODERN — UNIVERSAL SOURCE PACKAGE

This archive is prepared for sharing and installation from any extracted directory (including Downloads).
The generated build/ directory was intentionally removed because it contained machine-specific build paths.

Requirements: Slackware 15-compatible system, Meson, Ninja, compiler/toolchain, and required development libraries.

Run from this directory as root:
  ./script-install-gslapt.sh

The installer resolves its own directory, so it does not depend on the current working directory or a specific username/home directory.

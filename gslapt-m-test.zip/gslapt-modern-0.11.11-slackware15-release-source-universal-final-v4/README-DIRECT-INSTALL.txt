GSLAPT MODERN - UNIVERSAL SOURCE INSTALLER

Run as root from the source directory:

  ./script-install-gslapt.sh

Menu:

  1) Direct Meson installation
     Builds and installs Gslapt without creating a .txz package.
     A persistent installation manifest is saved in:
       /var/lib/gslapt-modern/installed.json

  2) Generate Slackware .txz package
     Creates the .txz package but does not install it.

  3) Generate .txz and install it
     Builds the package and installs it.

  4) Uninstall Gslapt
     If installed as a Slackware package, uses removepkg.
     If installed directly with Meson, uses the persistent manifest
     created by option 1. This remains available even if the source
     directory or build directory is later removed.

  0) Exit

The normal Gslapt application launcher is installed by Meson/SlackBuild
from gslapt.desktop.in.

Launcher: Exec=sudo -H /usr/bin/gslapt

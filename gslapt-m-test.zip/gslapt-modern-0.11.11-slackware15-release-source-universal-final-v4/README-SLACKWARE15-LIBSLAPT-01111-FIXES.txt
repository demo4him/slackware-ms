GSlapt modern UI - Slackware 15.0 / libslapt 0.11.11 compatibility fixes

This archive keeps the existing slapt-get/libslapt backend and adapts the Gslapt
frontend source to the API exposed by libslapt 0.11.11.

Fixed for libslapt 0.11.11:
- slapt_get_available_pkgs() takes no configuration argument.
- slapt_pkg_t_changelog() takes only a package argument.
- slapt_gen_filename_from_url() takes URL + filename.
- replaced unavailable slapt_gen_abs_path() with GLib g_build_filename().
- restored the missing lsearch_upgrade_transaction() helper used by Gslapt.

Build:
  rm -rf build
  meson setup build --prefix=/usr --sysconfdir=/etc --mandir=/usr/man
  meson compile -C build

Compile as a normal user. Install only after a successful build.

Gslapt v11 source-tree runtime fix

This revision fixes source-tree execution with ./build/src/gslapt.
The program first looks for installed UI/CSS under /usr/share/gslapt/ui, then
fails over to the source tree configured by Meson. This avoids requiring an
installation just to test the build.

The libslapt 0.11.11 build fixes from the previous v11 package are retained.
The package_data message is separate: it means the local slapt-get package
cache has not been generated/updated yet; it is not a missing UI file.

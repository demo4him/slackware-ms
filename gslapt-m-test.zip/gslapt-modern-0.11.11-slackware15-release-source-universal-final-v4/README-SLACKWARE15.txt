Gslapt Modern — Slackware 15.0 compatibility build

Target:
  Slackware 15.0 (2022), x86_64
  libslapt 0.11.11

The Meson dependency requirement was adjusted from >=0.11.12
to >=0.11.11. No libslapt/slapt-get source was modified.

Clean build:
  rm -rf build
  meson setup build --prefix=/usr --sysconfdir=/etc --mandir=/usr/man
  meson compile -C build

The Python 3.9/EOL message from Meson is a warning and is unrelated
to the libslapt dependency failure.

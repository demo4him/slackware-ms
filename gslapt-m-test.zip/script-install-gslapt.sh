#!/bin/bash
# Gslapt Modern - universal source installer
# Keep this script beside the source directory; it can be launched from anywhere.
# Options: 1 direct Meson install, 2 build .txz, 3 build and install .txz, 4 uninstall.
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/gslapt-modern-0.11.11-slackware15-release-source-universal-final-v4"
BUILD_DIR="$SOURCE_DIR/build"
SLACKBUILD="$SOURCE_DIR/gslapt.Slackbuild"

die() { echo; echo "ERROR: $*"; exit 1; }
require_root() { [ "$(id -u)" -eq 0 ] || die "Run this script as root."; }

check_source() {
    [ -d "$SOURCE_DIR" ] || die "Source directory not found: $SOURCE_DIR. Keep this script beside the source folder."
    [ -f "$SOURCE_DIR/meson.build" ] || die "meson.build was not found in source directory."
    [ -d "$SOURCE_DIR/src" ] || die "src/ was not found in source directory."
    [ -d "$SOURCE_DIR/ui" ] || die "ui/ was not found in source directory."
}

uninstall_gslapt() {
    require_root
    echo
    echo "=============================================="
    echo " Uninstall Gslapt Modern"
    echo "=============================================="
    printf "Are you sure? [y/N]: "
    read -r ANSWER
    case "$ANSWER" in y|Y|yes|YES) ;; *) echo "Cancelled."; return 0 ;; esac

    if command -v removepkg >/dev/null 2>&1; then
        PKG_NAMES="$(find /var/log/packages -maxdepth 1 -type f -name 'gslapt-*' -printf '%f\n' 2>/dev/null || true)"
        if [ -n "$PKG_NAMES" ]; then
            for PKG_FILE in $PKG_NAMES; do echo "Removing package: $PKG_FILE"; removepkg "$PKG_FILE"; done
            echo "Gslapt package removed."
            return 0
        fi
    fi

    MANIFEST="/var/lib/gslapt-modern/installed.json"
    if [ -f "$MANIFEST" ]; then
        python3 - "$MANIFEST" <<'PYREMOVE'
import json, os, sys
try:
    with open(sys.argv[1], encoding="utf-8") as f: data=json.load(f)
except Exception as e:
    print("Could not read manifest:", e); sys.exit(1)
paths=[]
def collect(obj):
    if isinstance(obj,str): paths.append(obj)
    elif isinstance(obj,list):
        for item in obj: collect(item)
    elif isinstance(obj,dict):
        for key,value in obj.items():
            if isinstance(key,str) and key.startswith("/"): paths.append(key)
            collect(value)
collect(data)
for path in sorted(set(paths), reverse=True):
    if not (path.startswith("/usr/") or path.startswith("/etc/")): continue
    try:
        if os.path.isfile(path) or os.path.islink(path): os.unlink(path); print("Removed:",path)
    except FileNotFoundError: pass
    except OSError as e: print("Could not remove:",path,"-",e)
try: os.unlink(sys.argv[1])
except FileNotFoundError: pass
PYREMOVE
        rmdir /var/lib/gslapt-modern 2>/dev/null || true
        echo "Gslapt direct Meson installation removed."
        return 0
    fi
    echo "No Gslapt installation record was found. Nothing was removed."
    return 1
}

direct_install() {
    require_root
    command -v meson >/dev/null 2>&1 || die "Meson is not installed."
    command -v ninja >/dev/null 2>&1 || die "Ninja is not installed."
    cd "$SOURCE_DIR"
    if [ ! -d "$BUILD_DIR" ]; then
        meson setup "$BUILD_DIR" --prefix=/usr --sysconfdir=/etc --mandir=/usr/man --buildtype=release
    else
        meson setup "$BUILD_DIR" --prefix=/usr --sysconfdir=/etc --mandir=/usr/man --buildtype=release --reconfigure
    fi
    meson compile -C "$BUILD_DIR"
    mkdir -p /var/lib/gslapt-modern
    meson introspect --installed "$BUILD_DIR" > /var/lib/gslapt-modern/installed.json || die "Could not create the Meson installation manifest."
    meson install -C "$BUILD_DIR"
    for desktop in /usr/share/applications/gslapt.desktop /usr/share/applications/gslapt-kde.desktop; do
        if [ -f "$desktop" ]; then sed -i 's|^Exec=.*|Exec=sudo -H /usr/sbin/gslapt|' "$desktop"; fi
    done
    echo; echo "Gslapt installed directly."; echo "Executable: /usr/sbin/gslapt"
}

build_txz() {
    require_root
    command -v meson >/dev/null 2>&1 || die "Meson is not installed."
    command -v makepkg >/dev/null 2>&1 || die "/sbin/makepkg was not found."
    [ -x "$SLACKBUILD" ] || die "gslapt.Slackbuild is not executable."
    cd "$SOURCE_DIR"
    "$SLACKBUILD"
    PKG="$(find "$SOURCE_DIR" -maxdepth 1 -type f -name 'gslapt-*.txz' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2-)"
    [ -n "$PKG" ] || die "The SlackBuild finished, but no .txz package was found."
    echo; echo "TXZ package created: $PKG"
}

build_and_install_txz() {
    build_txz
    PKG="$(find "$SOURCE_DIR" -maxdepth 1 -type f -name 'gslapt-*.txz' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2-)"
    [ -n "$PKG" ] || die "No .txz package found."
    /sbin/upgradepkg --install-new "$PKG"
    echo "Gslapt installed from the .txz package."
}

check_source
while :; do
    clear
    echo "=================================================="
    echo " Gslapt Modern - Source Installer"
    echo "=================================================="
    echo "Source: $SOURCE_DIR"
    echo
    echo "  1) Install directly with Meson (no .txz package)"
    echo "  2) Generate Slackware .txz package (do not install)"
    echo "  3) Generate .txz and install it"
    echo "  4) Uninstall Gslapt"
    echo "  0) Exit"
    echo
    printf "Choose an option [0-4]: "
    read -r CHOICE
    case "$CHOICE" in
        1) direct_install; printf "\nPress Enter to return to the menu..."; read -r _ ;;
        2) build_txz; printf "\nPress Enter to return to the menu..."; read -r _ ;;
        3) build_and_install_txz; printf "\nPress Enter to return to the menu..."; read -r _ ;;
        4) uninstall_gslapt; printf "\nPress Enter to return to the menu..."; read -r _ ;;
        0) exit 0 ;;
        *) echo; echo "Invalid option."; sleep 1 ;;
    esac
done

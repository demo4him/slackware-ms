#!/bin/bash
#
# script-install-gslapt.sh
# Gslapt Modern - universal source installer
#
# Options:
#   1 - Build and install directly with Meson (no .txz)
#   2 - Build a Slackware .txz package
#   3 - Build .txz and install it
#

set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BUILD_DIR="$SCRIPT_DIR/build"
SLACKBUILD="$SCRIPT_DIR/gslapt.Slackbuild"

die() {
    echo
    echo "ERROR: $*"
    exit 1
}

require_root() {
    [ "$(id -u)" -eq 0 ] || die "Run this script as root."
}

uninstall_gslapt() {
    require_root

    echo
    echo "=============================================="
    echo " Uninstall Gslapt Modern"
    echo "=============================================="
    echo
    echo "This will remove Gslapt from this system."
    echo
    printf "Are you sure? [y/N]: "
    read -r ANSWER
    case "$ANSWER" in
        y|Y|yes|YES) ;;
        *)
            echo "Cancelled."
            return 0
            ;;
    esac

    # Slackware package installation: use the package database.
    if command -v removepkg >/dev/null 2>&1; then
        PKG_NAMES="$(find /var/log/packages -maxdepth 1 -type f -name 'gslapt-*' -printf '%f\n' 2>/dev/null || true)"
        if [ -n "$PKG_NAMES" ]; then
            echo
            for PKG_FILE in $PKG_NAMES; do
                echo "Removing package: $PKG_FILE"
                removepkg "$PKG_FILE"
            done
            echo
            echo "Gslapt package removed."
            return 0
        fi
    fi

    # Direct Meson installation: use the persistent manifest created
    # by option 1. This works even when the source/build directory is gone.
    MANIFEST="/var/lib/gslapt-modern/installed.json"
    if [ -f "$MANIFEST" ]; then
        echo
        echo "Meson installation manifest found."
        echo "Removing files installed by Gslapt..."

        python3 - "$MANIFEST" <<'PY'
import json
import os
import sys

manifest = sys.argv[1]

try:
    with open(manifest, "r", encoding="utf-8") as f:
        data = json.load(f)
except Exception as e:
    print("Could not read manifest:", e)
    sys.exit(1)

paths = []

# Meson versions have returned installed-file information in slightly
# different JSON shapes. Accept the common dict/list forms.
def collect(obj):
    if isinstance(obj, str):
        paths.append(obj)
    elif isinstance(obj, list):
        for item in obj:
            collect(item)
    elif isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(key, str) and key.startswith("/"):
                paths.append(key)
            collect(value)

collect(data)

seen = set()
for path in sorted(paths, reverse=True):
    if path in seen:
        continue
    seen.add(path)

    # Never allow the manifest to remove outside normal installation paths.
    if not (path.startswith("/usr/") or path.startswith("/etc/")):
        continue

    try:
        if os.path.isfile(path) or os.path.islink(path):
            os.unlink(path)
            print("Removed:", path)
    except FileNotFoundError:
        pass
    except OSError as e:
        print("Could not remove:", path, "-", e)

try:
    os.unlink(manifest)
except FileNotFoundError:
    pass
PY

        rmdir /var/lib/gslapt-modern 2>/dev/null || true

        echo
        echo "Gslapt direct Meson installation removed."
        return 0
    fi

    echo
    echo "No Gslapt installation record was found."
    echo "Nothing was removed."
    return 1
}

check_source() {
    [ -f "$SCRIPT_DIR/meson.build" ] || die "meson.build was not found."
    [ -d "$SCRIPT_DIR/src" ] || die "src/ was not found."
    [ -d "$SCRIPT_DIR/ui" ] || die "ui/ was not found."
}

direct_install() {
    require_root
    command -v meson >/dev/null 2>&1 || die "Meson is not installed."
    command -v ninja >/dev/null 2>&1 || die "Ninja is not installed."

    echo
    echo "=============================================="
    echo " Direct Meson installation"
    echo "=============================================="
    echo
    echo "No .txz package will be created."
    echo

    cd "$SCRIPT_DIR"

    if [ ! -d "$BUILD_DIR" ]; then
        meson setup "$BUILD_DIR" \
            --prefix=/usr \
            --sysconfdir=/etc \
            --mandir=/usr/man \
            --buildtype=release
    else
        meson setup "$BUILD_DIR" \
            --prefix=/usr \
            --sysconfdir=/etc \
            --mandir=/usr/man \
            --buildtype=release \
            --reconfigure
    fi

    echo
    echo "Building..."
    meson compile -C "$BUILD_DIR"

    echo
    echo "Recording installed files..."
    mkdir -p /var/lib/gslapt-modern

    # Meson reports the files belonging to the configured installation.
    # Keep the manifest outside the source tree so uninstall still works
    # after the source/build directory is removed.
    meson introspect --installed "$BUILD_DIR" \
        > /var/lib/gslapt-modern/installed.json \
        || die "Could not create the Meson installation manifest."

    echo
    echo "Installing..."
    meson install -C "$BUILD_DIR"

    # Keep the desktop launcher explicit and identical on every system.
    # Gslapt is a privileged package manager, so it must be started through sudo.
    if [ -f /usr/share/applications/gslapt.desktop ]; then
        sed -i 's|^Exec=.*|Exec=sudo -H /usr/sbin/gslapt|'             /usr/share/applications/gslapt.desktop
    fi
    if [ -f /usr/share/applications/gslapt-kde.desktop ]; then
        sed -i 's|^Exec=.*|Exec=sudo -H /usr/sbin/gslapt|'             /usr/share/applications/gslapt-kde.desktop
    fi

    echo
    echo "=============================================="
    echo " Gslapt installed directly."
    echo "=============================================="
    echo
    echo "Executable: /usr/sbin/gslapt"
    echo "Launcher:   /usr/share/applications/gslapt.desktop"
    echo "Manifest:   /var/lib/gslapt-modern/installed.json"
}

build_txz() {
    require_root
    command -v meson >/dev/null 2>&1 || die "Meson is not installed."
    command -v makepkg >/dev/null 2>&1 || die "/sbin/makepkg was not found."
    [ -x "$SLACKBUILD" ] || die "gslapt.Slackbuild is not executable."

    echo
    echo "=============================================="
    echo " Slackware .txz package"
    echo "=============================================="
    echo

    cd "$SCRIPT_DIR"

    # The SlackBuild owns its complete package build.
    # Do not run the direct-install build first.
    "$SLACKBUILD"

    PKG="$(find "$SCRIPT_DIR" -maxdepth 1 -type f -name 'gslapt-*.txz' -printf '%T@ %p\n' 2>/dev/null \
        | sort -nr | head -n1 | cut -d' ' -f2-)"

    [ -n "$PKG" ] || die "The SlackBuild finished, but no .txz package was found."

    echo
    echo "TXZ package created:"
    echo "  $PKG"
    echo
}

build_and_install_txz() {
    build_txz
    PKG="$(find "$SCRIPT_DIR" -maxdepth 1 -type f -name 'gslapt-*.txz' -printf '%T@ %p\n' 2>/dev/null \
        | sort -nr | head -n1 | cut -d' ' -f2-)"
    [ -n "$PKG" ] || die "No .txz package found."
    echo "Installing:"
    echo "  $PKG"
    /sbin/upgradepkg --install-new "$PKG"
    echo
    echo "Gslapt installed from the .txz package."
}

check_source

while :; do
    clear
    echo "=================================================="
    echo " Gslapt Modern - Source Installer"
    echo "=================================================="
    echo
    echo "  1) Install directly with Meson"
    echo "     (no .txz package)"
    echo
    echo "  2) Generate Slackware .txz package"
    echo "     (do not install)"
    echo
    echo "  3) Generate .txz and install it"
    echo
    echo "  4) Uninstall Gslapt"
    echo
    echo "  0) Exit"
    echo
    printf "Choose an option [0-4]: "
    read -r CHOICE

    case "$CHOICE" in
        1)
            direct_install
            printf "\nPress Enter to return to the menu..."
            read -r _
            ;;
        2)
            build_txz
            printf "\nPress Enter to return to the menu..."
            read -r _
            ;;
        3)
            build_and_install_txz
            printf "\nPress Enter to return to the menu..."
            read -r _
            ;;
        4)
            uninstall_gslapt
            printf "\nPress Enter to return to the menu..."
            read -r _
            ;;
        0)
            exit 0
            ;;
        *)
            echo
            echo "Invalid option."
            sleep 1
            ;;
    esac
done

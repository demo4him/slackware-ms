#!/bin/bash

set -u

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
WINE="/opt/winecx/bin/wine"
WINESERVER="/opt/winecx/bin/wineserver"
PREFIX="$HOME/.winecx-office2007"
LOG_DIR="$BASE_DIR/logs"

echo "=========================================="
echo " Office 2007 Proofing Tools Installer"
echo " Romanian + English"
echo "=========================================="

if [ "$(id -u)" -eq 0 ]; then
    echo "ERROR: Do not run this installer as root."
    exit 1
fi

if [ ! -x "$WINE" ] || [ ! -x "$WINESERVER" ]; then
    echo "ERROR: WineCX was not found in /opt/winecx."
    exit 1
fi

if [ ! -d "$PREFIX/drive_c" ]; then
    echo "ERROR: Office 2007 WineCX prefix was not found:"
    echo "$PREFIX"
    exit 1
fi

cd "$BASE_DIR" || exit 1

echo
echo "Checking package integrity..."

if ! sha256sum -c SHA256SUMS; then
    echo "ERROR: SHA256 verification failed."
    exit 1
fi

mkdir -p "$LOG_DIR"
export WINEPREFIX="$PREFIX"

install_language() {
    local language="$1"
    local msi="$BASE_DIR/Proof.$language/Proof.msi"
    local log="$LOG_DIR/install-proof-$language.log"

    echo
    echo "Installing $language proofing components..."

    if [ ! -f "$msi" ]; then
        echo "ERROR: Missing MSI file: $msi"
        return 1
    fi

    "$WINE" msiexec /i "$msi" /L*v "$log"
    local status=$?

    "$WINESERVER" -w

    if [ "$status" -ne 0 ] && [ "$status" -ne 194 ]; then
        echo "ERROR: Installation failed with exit code $status."
        echo "See installation log: $log"
        return "$status"
    fi

    echo "$language installation completed."
}

install_language ro || exit 1
install_language en || exit 1

echo
echo "=========================================="
echo " Proofing installation completed."
echo " Languages: Romanian and English"
echo " Installation logs: $LOG_DIR"
echo "=========================================="

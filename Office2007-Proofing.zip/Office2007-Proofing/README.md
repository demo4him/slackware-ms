# Office 2007 Proofing Tools
## Romanian and English

A WineCX installation package for Microsoft Office 2007
Romanian and English proofing components.

### Requirements

- Slackware Linux
- WineCX installed in /opt/winecx
- Microsoft Office 2007 installed in:
  ~/.winecx-office2007

### Installation

Extract the archive and run as a normal user:

    chmod +x install-proofing.sh
    ./install-proofing.sh

### Features

- SHA256 integrity verification
- Romanian proofing installation
- English proofing installation
- Separate installation logs
- Automatic WineCX prefix detection through HOME
- No French proofing components

### Logs

Installation logs are saved in the logs directory.

### Important

This package contains proprietary Microsoft components.
Redistribution requires appropriate authorization.
